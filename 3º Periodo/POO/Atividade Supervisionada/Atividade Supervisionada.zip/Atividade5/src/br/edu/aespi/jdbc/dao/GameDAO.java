
package br.edu.aespi.jdbc.dao;

import br.edu.aespi.jdbc.modelo.Game;
import java.sql.Connection;
import factory.ConnectionFactory;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;


 


public class GameDAO {
    private Connection connection;
    
    public GameDAO() throws ClassNotFoundException{
        this.connection = new ConnectionFactory().getConnection();
    }
    
    public void adiciona(Game game){
    
        String sql = "insert into jogos"
                + "(titulo,preco,faixa_etaria,genero,descricao)"
                + "values (?,?,?,?,?)";
        
        try(
        PreparedStatement stmt = connection.prepareStatement(sql)){
        stmt.setString (1, game.getTitulo());
        stmt.setString (2, game.getPreco());
        stmt.setString (3, game.getFaixa_Etaria());
        stmt.setString (4, game.getGenero());
        stmt.setString (5, game.getDescricao());
        
        stmt.execute();
        }catch (SQLException ex){
            Logger.getLogger(GameDAO.class.getName())
                    .log(Level.SEVERE, null, ex);
        }
    }
    public List<Game> getJogos() throws SQLException{
        List<Game> listaDeJogos = new ArrayList<>();
        
        try{
            String sql = "select * from jogos";
            
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                
                Long id = rs.getLong("id");
                String titulo = rs.getString("titulo");
                String preco = rs.getString("preco");
                String faixa_etaria = rs.getString("faixa_etaria");
                String genero = rs.getString("genero");
                String descricao = rs.getString("descricao");
                
                
                Game game = new Game();
                game.setId(id);
                game.setTitulo(titulo);
                game.setPreco(preco);
                game.setFaixa_Etaria(faixa_etaria);
                game.setGenero(genero);
                game.setDescricao(descricao);
                
                listaDeJogos.add(game);
            }
        }catch (SQLException ex) {
          System.err.println(ex.getMessage());
        }
        return listaDeJogos;
    }
    public void deletaJogo(Long id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM jogos WHERE id = ?";

        try (
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            stmt.setLong(1, id);
            stmt.executeUpdate();
        }
}
    public void atualizaJogo(Long id, String titulo, String preco, String faixa_etaria, String genero, String descricao) throws SQLException {
    String sql = "UPDATE jogos SET titulo = ?, preco = ?, faixa_etaria = ?, genero = ?, descricao = ? WHERE id = ?";
    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        stmt.setString(1, titulo);
        stmt.setString(2, preco);
        stmt.setString(3, faixa_etaria);
        stmt.setString(4, genero);
        stmt.setString(5, descricao);
        stmt.setLong(6, id);
        stmt.executeUpdate();
    }
}

    
}

