/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package br.edu.aespi.jdbc.modelo;


public class Game {
    private Long id;
    private String titulo;
    private String preco;
    private String faixa_etaria;
    private String genero;
    private String descricao;

  
    public Long getId() {
        return id;
    }

  
    public void setId(Long id) {
        this.id = id;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getPreco() {
        return preco;
    }

  
    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getFaixa_Etaria() {
        return faixa_etaria;
    }

 
    public void setFaixa_Etaria(String faixa_etaria) {
        this.faixa_etaria = faixa_etaria;
    }

   
    public String getGenero() {
        return genero;
    }

  
    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public String getDescricao() {
        return descricao;
    }

  
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
}
